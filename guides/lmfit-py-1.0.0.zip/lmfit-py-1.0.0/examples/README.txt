Examples gallery
================

Below are examples of the different things you can do with lmfit.
Click on any image to see the complete source code and output.

We encourage users (i.e., YOU) to submit user-guide-style, documented,
and preferably self-contained examples of how you use lmfit for
inclusion in this gallery! Please note that many of the examples
below currently do *not* follow these guidelines yet.
